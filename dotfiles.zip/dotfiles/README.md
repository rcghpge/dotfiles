# dotfiles
[![PowerShell](https://github.com/rcghpge/dotfiles/actions/workflows/powershell.yml/badge.svg)](https://github.com/rcghpge/dotfiles/actions/workflows/powershell.yml)
[![Shell Lint](https://github.com/rcghpge/dotfiles/actions/workflows/lint.yml/badge.svg)](https://github.com/rcghpge/dotfiles/actions/workflows/lint.yml)

<p align="center">
  <img src="https://github.com/rcghpge/dotfiles/blob/main/assets/dotfiles.png?raw=true" width="100%" alt="p">
</p>

This repository contains dotfiles for:

- FreeBSD 
- Linux 
- Windows

---

## License

MIT

---
