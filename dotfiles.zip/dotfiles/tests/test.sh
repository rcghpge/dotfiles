#!/usr/bin/env bash
# Shell script tests

# test pass on shellcheck
echo "test shell linter on gh actions"
shellcheck --version
echo "test complete"

